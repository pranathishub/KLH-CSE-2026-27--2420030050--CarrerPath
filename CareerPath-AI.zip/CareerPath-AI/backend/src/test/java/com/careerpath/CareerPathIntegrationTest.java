package com.careerpath;

import com.careerpath.dto.Requests.*;
import com.careerpath.entity.*;
import com.careerpath.repository.*;
import com.careerpath.service.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
class CareerPathIntegrationTest {
    @Autowired AuthService auth;
    @Autowired CareerService careers;
    @Autowired AssessmentService assessments;
    @Autowired SkillRepository skillRepository;
    @Autowired CareerRepository careerRepository;
    @Autowired QuestionRepository questionRepository;

    private User register(String email) {
        auth.register(new Register("Test Student", email, "password123", "Test College", 3));
        return auth.user(((User) auth.login(new Login(email, "password123")).get("user")).id);
    }

    @Test
    void registrationStoresABcryptPassword() {
        User user = register("register@test.dev");
        assertThat(user.password).startsWith("$2").doesNotContain("password123");
    }

    @Test
    void loginReturnsAJwtForValidCredentials() {
        register("login@test.dev");
        assertThat(auth.login(new Login("login@test.dev", "password123"))).containsKeys("token", "user");
    }

    @Test
    void recommendationUsesRequiredSkillMatches() {
        User user = register("recommend@test.dev");
        for (String name : new String[]{"Java", "HTML", "CSS", "JavaScript", "React", "SQL", "Spring Boot"}) {
            careers.saveSkill(user.id, skillRepository.findByName(name).orElseThrow().id, 100);
        }
        assertThat(careers.recommendations(user.id).getFirst().career().name).isEqualTo("Full Stack Developer");
        assertThat(careers.recommendations(user.id).getFirst().match()).isEqualTo(100);
    }

    @Test
    void skillGapComparesCurrentAndRequiredLevels() {
        User user = register("gap@test.dev");
        Career backend = careerRepository.findByName("Backend Developer").orElseThrow();
        Skill java = skillRepository.findByName("Java").orElseThrow();
        careers.saveSkill(user.id, java.id, 80);
        assertThat(careers.gap(user.id, backend.id)).anySatisfy(gap -> {
            if (gap.skill().equals("Java")) assertThat(gap.status()).isEqualTo("Strong");
        }).anyMatch(gap -> gap.skill().equals("Spring Boot") && gap.status().equals("Gap"));
    }

    @Test
    void assessmentCalculatesScoreAndCategoryResults() {
        User user = register("assessment@test.dev");
        Map<Long, String> answers = new LinkedHashMap<>();
        questionRepository.findAll().forEach(q -> answers.put(q.id, q.correctAnswer));
        Assessment result = assessments.submit(user.id, answers);
        assertThat(result.score).isEqualTo(20);
        assertThat(result.percentage).isEqualTo(100);
        assertThat(result.categories.values()).allMatch(value -> value == 100);
    }
}
