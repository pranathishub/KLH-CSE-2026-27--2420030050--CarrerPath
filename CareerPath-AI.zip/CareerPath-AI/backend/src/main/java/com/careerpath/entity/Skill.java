package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class Skill {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(unique=true,nullable=false) public String name;
 public String category;
}
