package com.careerpath.service;
import com.careerpath.entity.*;import com.careerpath.repository.*;import com.careerpath.exception.ApiException;
import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import java.util.*;
@Service
public class AssessmentService {
 private final QuestionRepository questions;private final AssessmentRepository results;private final AuthService auth;
 public AssessmentService(QuestionRepository q,AssessmentRepository r,AuthService a){questions=q;results=r;auth=a;}
 public List<Question> questions(){return questions.findAll();}
 public List<Assessment> results(Long id){return results.findByUserIdOrderByDateDesc(id);}
 @Transactional public Assessment submit(Long id,Map<Long,String> answers){List<Question> all=questions();Set<Long> expected=new HashSet<>();all.forEach(q->expected.add(q.id));if(all.isEmpty()||!answers.keySet().equals(expected)||answers.values().stream().anyMatch(v->v==null||!v.matches("[ABCD]")))throw ApiException.invalid("Answer every question once before submitting.");Assessment a=new Assessment();a.user=auth.user(id);a.total=all.size();a.date=java.time.Instant.now();Map<String,Integer> totals=new LinkedHashMap<>(),correct=new HashMap<>();for(Question q:all){totals.merge(q.category,1,Integer::sum);if(q.correctAnswer.equals(answers.get(q.id))){a.score++;correct.merge(q.category,1,Integer::sum);}}a.percentage=(int)Math.round(100.0*a.score/a.total);totals.forEach((category,count)->a.categories.put(category,(int)Math.round(100.0*correct.getOrDefault(category,0)/count)));return results.save(a);}
}
