package com.careerpath.repository;
import com.careerpath.entity.RoadmapItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface RoadmapItemRepository extends JpaRepository<RoadmapItem,Long> {  }
