package com.careerpath.config;

import com.careerpath.entity.*;
import com.careerpath.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Component
public class DataSeeder implements CommandLineRunner {
    private final SkillRepository skills;
    private final CareerRepository careers;
    private final CareerSkillRepository careerSkills;
    private final QuestionRepository questions;
    private final UserRepository users;
    private final UserSkillRepository userSkills;
    private final PasswordEncoder encoder;
    private final boolean demoEnabled;
    private final String demoPassword;

    public DataSeeder(SkillRepository skills, CareerRepository careers,
                      CareerSkillRepository careerSkills, QuestionRepository questions,
                      UserRepository users, UserSkillRepository userSkills,
                      PasswordEncoder encoder,
                      @Value("${app.demo.enabled:false}") boolean demoEnabled,
                      @Value("${app.demo.password:}") String demoPassword) {
        this.skills = skills;
        this.careers = careers;
        this.careerSkills = careerSkills;
        this.questions = questions;
        this.users = users;
        this.userSkills = userSkills;
        this.encoder = encoder;
        this.demoEnabled = demoEnabled;
        this.demoPassword = demoPassword;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (skills.count() == 0) seedSkills();
        if (careers.count() == 0) seedCareers();
        if (questions.count() == 0) seedQuestions();
        if (demoEnabled && !demoPassword.isBlank()) seedDemoUser();
    }

    private void seedSkills() {
        addSkills("Programming", "Java", "JavaScript", "Python", "Dart", "Data Structures");
        addSkills("Web Development", "HTML", "CSS", "React", "Angular", "Spring Boot", "REST APIs");
        addSkills("Database", "SQL", "PostgreSQL", "MongoDB");
        addSkills("Cloud", "AWS", "Kubernetes", "Terraform", "Networking");
        addSkills("DevOps", "Git", "Docker", "Linux", "CI/CD", "Jenkins");
        addSkills("Cybersecurity", "Cybersecurity", "OWASP");
        addSkills("AI/ML", "Machine Learning", "Pandas", "NumPy", "Statistics");
        addSkills("Data", "Power BI");
        addSkills("Mobile", "Flutter");
    }

    private void addSkills(String category, String... names) {
        for (String name : names) {
            Skill skill = new Skill();
            skill.name = name;
            skill.category = category;
            skills.save(skill);
        }
    }

    private void seedCareers() {
        addCareer("Full Stack Developer", "Builds complete web applications across the browser, server, and database.",
                "React, Spring Boot, PostgreSQL", "Responsive interfaces, REST APIs, authentication, deployment", "web",
                req("HTML", 70, "CSS", 65, "JavaScript", 70, "React", 65, "Java", 65, "Spring Boot", 60, "SQL", 60));
        addCareer("Backend Developer", "Designs secure APIs, business logic, and reliable data services.",
                "Java, Spring Boot, PostgreSQL, Docker", "API design, security, testing, database performance", "backend",
                req("Java", 75, "Spring Boot", 70, "REST APIs", 70, "SQL", 65, "PostgreSQL", 60, "Git", 55));
        addCareer("Frontend Developer", "Creates accessible, responsive, and engaging user interfaces.",
                "HTML, CSS, JavaScript, React", "Component design, state, accessibility, performance", "web",
                req("HTML", 75, "CSS", 75, "JavaScript", 75, "React", 70, "Git", 55, "REST APIs", 50));
        addCareer("Data Analyst", "Turns business data into useful insights, dashboards, and decisions.",
                "SQL, Python, Pandas, Power BI", "Data cleaning, exploratory analysis, dashboards, storytelling", "data",
                req("SQL", 75, "Python", 60, "Pandas", 65, "Statistics", 60, "Power BI", 70));
        addCareer("Data Scientist", "Uses statistics and machine learning to solve data-driven problems.",
                "Python, Pandas, NumPy, scikit-learn", "Experiment design, feature engineering, modeling, evaluation", "data",
                req("Python", 75, "Pandas", 70, "NumPy", 65, "Statistics", 75, "Machine Learning", 70, "SQL", 60));
        addCareer("Machine Learning Engineer", "Builds, tests, and deploys production machine-learning systems.",
                "Python, ML, Docker, AWS", "Model pipelines, APIs, monitoring, cloud deployment", "ai",
                req("Python", 80, "Machine Learning", 80, "NumPy", 70, "Statistics", 70, "Docker", 60, "AWS", 55));
        addCareer("Cloud Engineer", "Designs and operates scalable infrastructure on cloud platforms.",
                "AWS, Linux, Networking, Terraform", "Cloud architecture, infrastructure as code, observability", "cloud",
                req("AWS", 75, "Linux", 70, "Networking", 70, "Terraform", 65, "Docker", 60, "Cybersecurity", 55));
        addCareer("DevOps Engineer", "Automates software delivery and keeps systems reliable.",
                "Linux, Docker, Kubernetes, Jenkins", "CI/CD, containers, monitoring, release automation", "devops",
                req("Linux", 75, "Docker", 75, "Kubernetes", 65, "CI/CD", 75, "Jenkins", 60, "Git", 65));
        addCareer("Cybersecurity Analyst", "Finds vulnerabilities, monitors threats, and protects systems and data.",
                "Networking, Linux, OWASP, security tools", "Threat analysis, web security, incident response", "security",
                req("Cybersecurity", 80, "Networking", 75, "Linux", 65, "OWASP", 75, "Python", 50));
        addCareer("Mobile App Developer", "Creates cross-platform mobile applications with polished user experiences.",
                "Flutter, Dart, REST APIs", "Layouts, state management, device features, app publishing", "mobile",
                req("Flutter", 75, "Dart", 75, "REST APIs", 60, "Git", 55, "SQL", 45));
    }

    private Map<String, Integer> req(Object... values) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < values.length; i += 2) map.put((String) values[i], (Integer) values[i + 1]);
        return map;
    }

    private void addCareer(String name, String description, String technologies, String topics,
                           String interest, Map<String, Integer> requirements) {
        Career career = new Career();
        career.name = name;
        career.description = description;
        career.technologies = technologies;
        career.topics = topics;
        career.interest = interest;
        careers.save(career);
        requirements.forEach((skillName, level) -> {
            CareerSkill requirement = new CareerSkill();
            requirement.career = career;
            requirement.skill = skills.findByName(skillName).orElseThrow();
            requirement.requiredLevel = level;
            careerSkills.save(requirement);
        });
    }

    private void seedQuestions() {
        addQuestion("Programming", "Which language is primarily used for Spring Boot applications?", "Python", "Java", "C", "PHP", "B");
        addQuestion("Programming", "What does object-oriented encapsulation protect?", "Internal object state", "Network packets", "Database rows", "HTML tags", "A");
        addQuestion("Programming", "Which structure follows last-in, first-out order?", "Queue", "Tree", "Stack", "Graph", "C");
        addQuestion("Database", "Which SQL keyword combines rows from related tables?", "JOIN", "GROUP", "ORDER", "CREATE", "A");
        addQuestion("Database", "What uniquely identifies each row in a table?", "Foreign key", "Primary key", "Index name", "View", "B");
        addQuestion("Database", "Which normal form removes repeating groups?", "1NF", "2NF", "3NF", "BCNF", "A");
        addQuestion("Web Development", "Which React hook stores component state?", "useFetch", "useState", "useClass", "useRoute", "B");
        addQuestion("Web Development", "Which HTTP method usually creates a resource?", "GET", "DELETE", "POST", "HEAD", "C");
        addQuestion("Web Development", "Which CSS layout is one-dimensional?", "Grid", "Flexbox", "Table", "Float", "B");
        addQuestion("Data Structures", "What is binary search time complexity?", "O(1)", "O(log n)", "O(n)", "O(n²)", "B");
        addQuestion("Data Structures", "Which structure stores key-value pairs?", "Hash map", "Stack", "Linked list", "Heap", "A");
        addQuestion("Cloud", "Which cloud model provides virtual machines?", "SaaS", "IaaS", "DaaS", "FaaS only", "B");
        addQuestion("Cloud", "What does auto-scaling change?", "Source code", "Resource capacity", "Password length", "DNS names only", "B");
        addQuestion("Cybersecurity", "What does HTTPS protect in transit?", "Screen brightness", "Network traffic", "File names only", "CPU usage", "B");
        addQuestion("Cybersecurity", "Which attack injects script into a web page?", "XSS", "DDoS", "Phishing", "Brute force", "A");
        addQuestion("AI/ML", "Which dataset is used to evaluate a trained model?", "Test set", "Source set", "Build set", "Cache set", "A");
        addQuestion("AI/ML", "Supervised learning requires what?", "Labeled examples", "No data", "Only images", "A compiler", "A");
        addQuestion("DevOps", "What does CI commonly automate?", "Code integration and tests", "Hiring", "Graphic design", "Database deletion", "A");
        addQuestion("DevOps", "What does a Docker image describe?", "A repeatable container filesystem", "A database join", "A Git branch", "A DNS record", "A");
        addQuestion("DevOps", "Which tool tracks source-code history?", "Git", "Postman", "Figma", "Excel", "A");
    }

    private void addQuestion(String category, String text, String a, String b, String c, String d, String answer) {
        Question q = new Question();
        q.category = category;
        q.question = text;
        q.optionA = a;
        q.optionB = b;
        q.optionC = c;
        q.optionD = d;
        q.correctAnswer = answer;
        questions.save(q);
    }

    private void seedDemoUser() {
        if (users.existsByEmail("demo@careerpath.ai")) return;
        User user = new User();
        user.name = "Aarav Sharma";
        user.email = "demo@careerpath.ai";
        user.password = encoder.encode(demoPassword);
        user.college = "National Institute of Technology";
        user.branch = "Computer Science";
        user.year = 3;
        user.interests = "web, backend, cloud";
        user.careerGoal = "Full Stack Developer";
        users.save(user);
        Map<String, Integer> levels = Map.of("Java", 80, "HTML", 85, "CSS", 72, "JavaScript", 68, "React", 52, "SQL", 70, "Spring Boot", 42, "Git", 70);
        levels.forEach((name, level) -> {
            UserSkill entry = new UserSkill();
            entry.user = user;
            entry.skill = skills.findByName(name).orElseThrow();
            entry.level = level;
            userSkills.save(entry);
        });
    }
}
