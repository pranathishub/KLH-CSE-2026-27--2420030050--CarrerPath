package com.careerpath.security;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
@Component
public class JwtFilter extends OncePerRequestFilter {
 private final JwtService jwt;
 public JwtFilter(JwtService jwt){this.jwt=jwt;}
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException {
  String header=req.getHeader("Authorization");
  if(header!=null && header.startsWith("Bearer ")){
   try {Long id=jwt.userId(header.substring(7));SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(id,null,List.of()));}
   catch(io.jsonwebtoken.JwtException|IllegalArgumentException ex){SecurityContextHolder.clearContext();res.setStatus(401);res.setContentType("application/json");res.getWriter().write("{\"message\":\"Your session has expired. Please log in again.\"}");return;}
  }
  chain.doFilter(req,res);
 }
}
