package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"career_id","skill_id"}))
public class CareerSkill {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @JoinColumn(name="career_id") @com.fasterxml.jackson.annotation.JsonIgnore public Career career;
 @ManyToOne(optional=false) @JoinColumn(name="skill_id") public Skill skill;
 public int requiredLevel;
}
