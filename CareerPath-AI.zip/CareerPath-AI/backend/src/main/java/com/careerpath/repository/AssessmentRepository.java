package com.careerpath.repository;
import com.careerpath.entity.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AssessmentRepository extends JpaRepository<Assessment,Long> { java.util.List<Assessment> findByUserIdOrderByDateDesc(Long id); }
