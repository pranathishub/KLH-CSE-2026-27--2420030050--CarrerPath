package com.careerpath.service;
import com.careerpath.entity.*;
import com.careerpath.repository.*;
import com.careerpath.exception.ApiException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
@Service
@Transactional(readOnly=true)
public class CareerService {
 private final CareerRepository careers;private final CareerSkillRepository requirements;private final UserSkillRepository userSkills;private final SkillRepository skills;private final AuthService auth;
 public CareerService(CareerRepository c,CareerSkillRepository r,UserSkillRepository u,SkillRepository s,AuthService a){careers=c;requirements=r;userSkills=u;skills=s;auth=a;}
 public List<Career> careers(){return careers.findAll();}
 public Career career(Long id){return careers.findById(id).orElseThrow(()->ApiException.missing("Career"));}
 public Map<String,Object> detail(Long id){Career c=career(id);List<CareerSkill> req=requirements.findByCareerId(id);return Map.of("career",c,"requirements",req,"averageLevel",Math.round(req.stream().mapToInt(r->r.requiredLevel).average().orElse(0)));}
 public List<Skill> skills(){return skills.findAll();}
 public List<UserSkill> userSkills(Long id){return userSkills.findByUserId(id);}
 @Transactional public UserSkill saveSkill(Long userId,Long skillId,int level){UserSkill u=userSkills.findByUserIdAndSkillId(userId,skillId).orElseGet(()->{UserSkill s=new UserSkill();s.user=auth.user(userId);s.skill=skills.findById(skillId).orElseThrow(()->ApiException.missing("Skill"));return s;});u.level=level;return userSkills.save(u);}
 @Transactional public UserSkill updateSkill(Long userId,Long id,int level){UserSkill u=userSkills.findById(id).filter(s->s.user.id.equals(userId)).orElseThrow(()->ApiException.missing("User skill"));u.level=level;return userSkills.save(u);}
 public record Gap(Long skillId,String skill,String category,int currentLevel,int requiredLevel,String status) {}
 public List<Gap> gap(Long userId,Long careerId){career(careerId);Map<Long,Integer> current=new HashMap<>();userSkills(userId).forEach(s->current.put(s.skill.id,s.level));return requirements.findByCareerId(careerId).stream().map(r->{int level=current.getOrDefault(r.skill.id,0);return new Gap(r.skill.id,r.skill.name,r.skill.category,level,r.requiredLevel,level>=r.requiredLevel?"Strong":level>=r.requiredLevel-20?"Improve":"Gap");}).toList();}
 public record Recommendation(Career career,int match,int matched,int total,boolean interestMatch,List<String> reasons) {}
 public List<Recommendation> recommendations(Long id){User user=auth.user(id);List<Recommendation> list=new ArrayList<>();for(Career c:careers()){List<Gap> gaps=gap(id,c.id);int matched=(int)gaps.stream().filter(g->g.currentLevel()>=g.requiredLevel()).count();int percent=gaps.isEmpty()?0:(int)Math.round(matched*100.0/gaps.size());boolean interest=user.interests.toLowerCase(Locale.ROOT).contains(c.interest.toLowerCase(Locale.ROOT));List<String> reasons=new ArrayList<>();reasons.add(matched+" of "+gaps.size()+" skills meet the target level.");gaps.stream().filter(g->g.status().equals("Strong")).limit(2).forEach(g->reasons.add("Ready in "+g.skill()+" ("+g.currentLevel()+"%)."));if(interest)reasons.add("Matches your interest in "+c.interest+".");if(matched==0)reasons.add("Add your skills to discover a more personal match.");list.add(new Recommendation(c,percent,matched,gaps.size(),interest,reasons));}list.sort(Comparator.comparingInt(Recommendation::match).reversed().thenComparing(Recommendation::interestMatch,Comparator.reverseOrder()).thenComparing(r->r.career().id));return list;}
}
