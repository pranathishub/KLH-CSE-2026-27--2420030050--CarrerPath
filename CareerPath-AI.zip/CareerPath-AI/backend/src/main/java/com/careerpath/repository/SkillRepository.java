package com.careerpath.repository;
import com.careerpath.entity.Skill;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SkillRepository extends JpaRepository<Skill,Long> { java.util.Optional<Skill> findByName(String name); }
