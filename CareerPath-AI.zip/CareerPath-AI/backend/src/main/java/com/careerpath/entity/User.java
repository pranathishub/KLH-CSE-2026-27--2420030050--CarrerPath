package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
@Table(name="app_users")
public class User {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String name;
 @Column(nullable=false,unique=true) public String email;
 @com.fasterxml.jackson.annotation.JsonIgnore @Column(nullable=false) public String password;
 public String college; public String branch = "Computer Science"; public int year;
 public String interests = ""; public String careerGoal = "";
}
