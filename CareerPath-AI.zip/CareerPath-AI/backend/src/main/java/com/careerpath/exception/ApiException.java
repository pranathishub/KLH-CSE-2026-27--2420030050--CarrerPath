package com.careerpath.exception;
import org.springframework.http.HttpStatus;
public class ApiException extends RuntimeException {
 public final HttpStatus status;
 public ApiException(HttpStatus status,String message){super(message);this.status=status;}
 public static ApiException missing(String name){return new ApiException(HttpStatus.NOT_FOUND,name+" not found.");}
 public static ApiException invalid(String message){return new ApiException(HttpStatus.BAD_REQUEST,message);}
}
