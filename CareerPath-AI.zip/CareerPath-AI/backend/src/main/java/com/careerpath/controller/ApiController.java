package com.careerpath.controller;
import com.careerpath.dto.Requests.*;import com.careerpath.service.*;
import org.springframework.web.bind.annotation.*;import org.springframework.http.HttpStatus;import org.springframework.security.core.annotation.AuthenticationPrincipal;import jakarta.validation.Valid;import java.util.Map;
@RestController
@RequestMapping("/api")
public class ApiController {
 private final AuthService auth;private final CareerService careers;private final AssessmentService assessments;private final RoadmapService roadmaps;
 public ApiController(AuthService a,CareerService c,AssessmentService s,RoadmapService r){auth=a;careers=c;assessments=s;roadmaps=r;}
 @GetMapping("/health") public Object health(){return Map.of("status","UP");}
 @PostMapping("/auth/register") @ResponseStatus(HttpStatus.CREATED) public Object register(@Valid @RequestBody Register r){return auth.register(r);}
 @PostMapping("/auth/login") public Object login(@Valid @RequestBody Login r){return auth.login(r);}
 @GetMapping("/users/profile") public Object profile(@AuthenticationPrincipal Long id){return auth.user(id);}
 @PutMapping("/users/profile") public Object profile(@AuthenticationPrincipal Long id,@Valid @RequestBody Profile r){return auth.profile(id,r);}
 @GetMapping("/skills") public Object skills(){return careers.skills();}
 @GetMapping("/users/skills") public Object skills(@AuthenticationPrincipal Long id){return careers.userSkills(id);}
 @PostMapping("/users/skills") @ResponseStatus(HttpStatus.CREATED) public Object skill(@AuthenticationPrincipal Long id,@Valid @RequestBody SkillInput r){return careers.saveSkill(id,r.skillId(),r.level());}
 @PutMapping("/users/skills/{skillId}") public Object skill(@AuthenticationPrincipal Long id,@PathVariable Long skillId,@Valid @RequestBody Level r){return careers.updateSkill(id,skillId,r.level());}
 @GetMapping("/careers") public Object careers(){return careers.careers();}
 @GetMapping("/careers/{careerId}") public Object career(@PathVariable Long careerId){return careers.detail(careerId);}
 @GetMapping("/careers/{careerId}/skill-gap") public Object gap(@AuthenticationPrincipal Long id,@PathVariable Long careerId){return careers.gap(id,careerId);}
 @GetMapping("/recommendations") public Object recommend(@AuthenticationPrincipal Long id){return careers.recommendations(id);}
 @GetMapping("/assessment/questions") public Object questions(){return assessments.questions();}
 @PostMapping("/assessment/submit") @ResponseStatus(HttpStatus.CREATED) public Object submit(@AuthenticationPrincipal Long id,@Valid @RequestBody Answers r){return assessments.submit(id,r.answers());}
 @GetMapping("/assessment/results") public Object results(@AuthenticationPrincipal Long id){return assessments.results(id);}
 @GetMapping("/roadmap") public Object roadmap(@AuthenticationPrincipal Long id){return roadmaps.list(id);}
 @PostMapping("/roadmap") @ResponseStatus(HttpStatus.CREATED) public Object roadmap(@AuthenticationPrincipal Long id,@Valid @RequestBody CreateRoadmap r){return roadmaps.create(id,r.careerId());}
 @PutMapping("/roadmap/items/{itemId}") public Object item(@AuthenticationPrincipal Long id,@PathVariable Long itemId,@Valid @RequestBody ItemStatus r){return roadmaps.update(id,itemId,r.status());}
 @GetMapping("/progress") public Object progress(@AuthenticationPrincipal Long id,@RequestParam(required=false) Long roadmapId){return roadmaps.progress(id,roadmapId);}
}
