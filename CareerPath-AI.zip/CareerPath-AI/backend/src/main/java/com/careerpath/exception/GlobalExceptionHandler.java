package com.careerpath.exception;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.dao.DataIntegrityViolationException;
import java.util.Map;
@RestControllerAdvice
public class GlobalExceptionHandler {
 @ExceptionHandler(ApiException.class) ResponseEntity<?> domain(ApiException ex){return ResponseEntity.status(ex.status).body(Map.of("message",ex.getMessage()));}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> validation(MethodArgumentNotValidException ex){return ResponseEntity.badRequest().body(Map.of("message",ex.getBindingResult().getFieldErrors().stream().map(e->e.getField()+": "+e.getDefaultMessage()).findFirst().orElse("Invalid request.")));}
 @ExceptionHandler({HttpMessageNotReadableException.class,org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class}) ResponseEntity<?> invalid(Exception ex){return ResponseEntity.badRequest().body(Map.of("message","Please check the request fields and try again."));}
 @ExceptionHandler(DataIntegrityViolationException.class) ResponseEntity<?> conflict(Exception ex){return ResponseEntity.status(409).body(Map.of("message","That record already exists or conflicts with another record."));}
 @ExceptionHandler(Exception.class) ResponseEntity<?> unexpected(Exception ex){org.slf4j.LoggerFactory.getLogger(getClass()).error("Unexpected API error",ex);return ResponseEntity.status(500).body(Map.of("message","Something went wrong. Please try again."));}
}
