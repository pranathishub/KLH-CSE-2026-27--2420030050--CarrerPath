package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"user_id","skill_id"}))
public class UserSkill {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @JoinColumn(name="user_id") @com.fasterxml.jackson.annotation.JsonIgnore public User user;
 @ManyToOne(optional=false) @JoinColumn(name="skill_id") public Skill skill;
 public int level;
}
