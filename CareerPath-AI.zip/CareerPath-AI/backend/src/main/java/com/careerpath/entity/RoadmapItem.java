package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class RoadmapItem {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @com.fasterxml.jackson.annotation.JsonIgnore public Roadmap roadmap;
 public String title; @Column(length=2000) public String description;
 @Enumerated(EnumType.STRING) public Status status = Status.NOT_STARTED;
 public int orderNumber;
 public enum Status { NOT_STARTED, IN_PROGRESS, COMPLETED }
}
