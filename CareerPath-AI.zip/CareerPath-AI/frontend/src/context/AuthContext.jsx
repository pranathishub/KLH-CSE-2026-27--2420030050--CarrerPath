import { createContext, useContext, useMemo, useState } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('careerpath_user')); } catch { return null; } });
  const saveSession = ({ token, user: nextUser }) => { localStorage.setItem('careerpath_token', token); localStorage.setItem('careerpath_user', JSON.stringify(nextUser)); setUser(nextUser); };
  const login = async values => saveSession((await api.post('/auth/login', values)).data);
  const register = async values => saveSession((await api.post('/auth/register', values)).data);
  const updateUser = nextUser => { localStorage.setItem('careerpath_user', JSON.stringify(nextUser)); setUser(nextUser); };
  const logout = () => { localStorage.removeItem('careerpath_token'); localStorage.removeItem('careerpath_user'); setUser(null); };
  const value = useMemo(() => ({ user, login, register, logout, updateUser }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
