import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { BarChart3, BookOpenCheck, BriefcaseBusiness, ClipboardCheck, Compass, LayoutDashboard, LogOut, Menu, Moon, Route, Sun, UserRound, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const links = [['/dashboard',LayoutDashboard,'Dashboard'],['/profile',UserRound,'Profile'],['/assessment',ClipboardCheck,'Assessment'],['/results',BarChart3,'Results'],['/careers',Compass,'Explore Careers'],['/skill-gap',BriefcaseBusiness,'Skill Gap'],['/roadmap',Route,'Roadmap'],['/progress',BookOpenCheck,'Progress']];
export default function AppLayout() {
  const { user, logout } = useAuth(); const [open,setOpen]=useState(false); const [dark,setDark]=useState(()=>localStorage.getItem('careerpath_theme')==='dark'); const location=useLocation();
  const title=links.find(([path])=>location.pathname.startsWith(path))?.[2]||'CareerPath AI';
  const toggleTheme=()=>{const next=!dark;setDark(next);localStorage.setItem('careerpath_theme',next?'dark':'light');};
  return <div className={`app-shell ${dark?'dark':''}`}>
    <aside className={`sidebar ${open?'open':''}`}><div className="sidebar-brand"><span>CP</span><b>CareerPath AI</b><button className="icon-button close-menu" onClick={()=>setOpen(false)} aria-label="Close menu"><X/></button></div><nav>{links.map(([path,Icon,label])=><NavLink key={path} to={path} onClick={()=>setOpen(false)}><Icon/>{label}</NavLink>)}</nav><button className="logout" onClick={logout}><LogOut/>Log out</button></aside>
    <div className="app-body"><header className="topbar"><button className="icon-button menu-button" onClick={()=>setOpen(true)} aria-label="Open menu"><Menu/></button><div><small>CareerPath AI</small><b>{title}</b></div><div className="top-actions"><button className="icon-button" onClick={toggleTheme} aria-label="Toggle theme">{dark?<Sun/>:<Moon/>}</button><div className="avatar">{user?.name?.split(' ').map(p=>p[0]).slice(0,2).join('')}</div><div className="user-summary"><b>{user?.name}</b><span>Year {user?.year} student</span></div></div></header><main className="app-content"><Outlet/></main></div>
    {open&&<button className="scrim" onClick={()=>setOpen(false)} aria-label="Close navigation"/>}
  </div>;
}
