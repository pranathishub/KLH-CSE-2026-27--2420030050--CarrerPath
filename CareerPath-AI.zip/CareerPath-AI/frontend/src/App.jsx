import { useEffect } from 'react';
import { Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import AppLayout from './layouts/AppLayout';
import { Assessment, CareerDetail, Careers, Dashboard, Landing, Login, Profile, Progress, Register, Results, Roadmap, SkillGap } from './pages/Pages';
import api from './services/api';

function Protected({ children }) { const { user } = useAuth(); return user ? children : <Navigate to="/login" replace />; }
function WebMcpTools() {
  const navigate = useNavigate();
  useEffect(() => {
    const context = document.modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const register = tool => Promise.resolve(context.registerTool(tool, { signal: lifecycle.signal })).catch(() => {});
    register({
      name: 'navigate_careerpath', title: 'Open CareerPath page',
      description: 'Open a main CareerPath AI page for the signed-in student.',
      inputSchema: { type:'object', properties:{ page:{ type:'string', enum:['dashboard','profile','assessment','careers','skill-gap','roadmap','progress'] } }, required:['page'], additionalProperties:false },
      annotations: { readOnlyHint:true, untrustedContentHint:false },
      execute: ({ page }) => { navigate(`/${page}`); return { page, opened:true }; }
    });
    register({
      name: 'save_student_skill_level', title: 'Save skill level',
      description: 'Save a signed-in student skill confidence level using an existing CareerPath skill ID.',
      inputSchema: { type:'object', properties:{ skillId:{type:'integer',minimum:1}, level:{type:'integer',minimum:0,maximum:100} }, required:['skillId','level'], additionalProperties:false },
      annotations: { readOnlyHint:false, untrustedContentHint:false },
      execute: async ({ skillId, level }) => { const { data } = await api.post('/users/skills',{skillId,level}); navigate('/profile'); return { skill:data.skill.name, level:data.level, saved:true }; }
    });
    return () => lifecycle.abort();
  }, [navigate]);
  return null;
}
export default function App() {
  return <><WebMcpTools/><Routes>
    <Route path="/" element={<Landing />} /><Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} />
    <Route element={<Protected><AppLayout /></Protected>}>
      <Route path="/dashboard" element={<Dashboard />} /><Route path="/profile" element={<Profile />} />
      <Route path="/assessment" element={<Assessment />} /><Route path="/results" element={<Results />} />
      <Route path="/careers" element={<Careers />} /><Route path="/careers/:id" element={<CareerDetail />} />
      <Route path="/skill-gap" element={<SkillGap />} /><Route path="/roadmap" element={<Roadmap />} /><Route path="/progress" element={<Progress />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes></>;
}
