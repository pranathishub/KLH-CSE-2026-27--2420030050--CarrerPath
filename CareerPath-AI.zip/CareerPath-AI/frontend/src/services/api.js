import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api' });
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('careerpath_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use(response => response, error => {
  if (error.response?.status === 401 && !error.config?.url?.includes('/auth/')) {
    localStorage.removeItem('careerpath_token');
    localStorage.removeItem('careerpath_user');
    window.location.assign('/login');
  }
  return Promise.reject(error);
});
export const messageOf = error => error.response?.data?.message || 'Unable to connect. Check that the backend is running.';
export default api;
