# CareerPath AI

CareerPath AI is a full-stack career guidance application for college students. It turns a student's interests, current skills, and assessment performance into transparent career recommendations, a skill-gap report, and a trackable learning roadmap.

## Problem statement

Technology students often know individual tools but do not know which career fits them, what employers expect for that career, or what to learn next. CareerPath AI keeps that decision process in one place and explains every result using stored skill requirements rather than a paid or opaque AI service.

## Objectives

- Help students compare ten common technology careers.
- Record a profile, interests, and confidence levels for technical skills.
- Measure knowledge across eight assessment categories.
- Recommend careers with an explainable rule-based score.
- Identify the exact difference between current and required skill levels.
- Generate and track a personal learning roadmap.

## Implemented features

- Registration, login, BCrypt password hashing, JWT sessions, and protected APIs
- Editable student profile and 31 seeded skills
- Twenty-question assessment with category performance and attempt history
- Ten seeded career paths with skill requirements and suggested technologies
- Explainable recommendation, skill-gap, roadmap, and progress services
- Responsive React dashboard with charts, empty states, validation, error messages, and light/dark mode
- PostgreSQL persistence, sample data initialization, global API error handling, and CORS configuration
- Backend tests for registration, login, recommendations, gap analysis, and assessment submission
- Optional WebMCP tools for navigation and skill updates in supported browsers

## Technology stack

| Layer | Technology |
| --- | --- |
| Frontend | React, Vite, JavaScript, React Router, Axios, Recharts, Lucide icons |
| Backend | Java 21, Spring Boot, Spring Web, Spring Data JPA, Spring Security, JWT, Maven |
| Database | PostgreSQL 17 |
| Testing | JUnit 5, Spring Boot Test, AssertJ, H2 test database |

## Architecture

```mermaid
flowchart LR
    U[Student] --> R[React + Vite]
    R -->|Axios + JWT| A[Spring Boot REST API]
    A --> S[Service layer]
    S --> J[Spring Data JPA]
    J --> P[(PostgreSQL)]
```

The frontend calls REST endpoints with a bearer token. Controllers validate requests, services hold the recommendation and roadmap rules, repositories isolate database access, and JPA manages relationships.

## Database schema

```mermaid
erDiagram
    USER ||--o{ USER_SKILL : has
    SKILL ||--o{ USER_SKILL : measures
    CAREER ||--o{ CAREER_SKILL : requires
    SKILL ||--o{ CAREER_SKILL : describes
    USER ||--o{ ASSESSMENT : takes
    USER ||--o{ ROADMAP : owns
    CAREER ||--o{ ROADMAP : targets
    ROADMAP ||--o{ ROADMAP_ITEM : contains
    ROADMAP ||--o{ PROGRESS_SNAPSHOT : records
```

Important relationships are `User` → `UserSkill`, `Career` → `CareerSkill`, and `Roadmap` → `RoadmapItem`. Join entities carry the student's current level or the career's required level.

## Run locally

Prerequisites: Java 21, Maven 3.9+, Node.js 20+, npm, and either Docker Desktop or PostgreSQL 17.

### 1. Start PostgreSQL

From this project directory:

```powershell
docker compose up -d postgres
```

If Docker is unavailable, create the database and role in PostgreSQL:

```sql
CREATE USER careerpath WITH PASSWORD 'careerpath_dev';
CREATE DATABASE careerpath OWNER careerpath;
```

### 2. Run the backend

```powershell
cd backend
mvn spring-boot:run "-Dspring-boot.run.profiles=dev"
```

The API runs at `http://localhost:8080/api`. The `dev` profile contains local-only demonstration values. For another environment, set the variables shown in `backend/.env.example` and run without the `dev` profile.

### 3. Run the frontend

Open a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

### Demonstration login

- Email: `demo@careerpath.ai`
- Password: `CareerPathDemo123!`

The demo account is created only when `DEMO_ENABLED=true`, including the provided local `dev` profile.

## Tests and production builds

```powershell
cd backend
mvn test

cd ../frontend
npm run build
```

The backend test profile uses an in-memory H2 database in PostgreSQL compatibility mode, so tests do not change local PostgreSQL data.

## Recommendation algorithm

Each career stores a list of required skills and a target level. A skill counts as matched when the student's saved level is at least the required level:

```text
match percentage = matched required skills / total required skills × 100
```

Careers are sorted by match percentage. A matching profile interest breaks ties. The result also lists the number of matched skills, strong skills, and any interest match, which makes the logic easy to explain and reproduce.

The skill-gap service uses the same inputs:

- `Strong`: current level meets or exceeds the target.
- `Improve`: current level is within 20 points of the target.
- `Gap`: current level is more than 20 points below the target.

## API summary

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register` | Create a student account |
| POST | `/api/auth/login` | Return a JWT and student data |
| GET / PUT | `/api/users/profile` | Read or update the profile |
| GET | `/api/skills` | List seeded skills |
| GET / POST | `/api/users/skills` | Read or save student skill levels |
| PUT | `/api/users/skills/{id}` | Update one user-skill record |
| GET | `/api/careers` | List careers |
| GET | `/api/careers/{id}` | Show career details and requirements |
| GET | `/api/careers/{id}/skill-gap` | Compare current and required levels |
| GET | `/api/recommendations` | Return ranked career matches |
| GET | `/api/assessment/questions` | Return assessment questions without answers |
| POST | `/api/assessment/submit` | Score and save one attempt |
| GET | `/api/assessment/results` | Return assessment history |
| GET / POST | `/api/roadmap` | Read or generate roadmaps |
| PUT | `/api/roadmap/items/{id}` | Change one roadmap item status |
| GET | `/api/progress` | Return roadmap totals and progress history |

All endpoints except authentication and `/api/health` require `Authorization: Bearer <token>`.

## Important files

- `backend/src/main/java/com/careerpath/config/SecurityConfig.java` — stateless security and CORS rules
- `backend/src/main/java/com/careerpath/security/JwtService.java` — JWT creation and verification
- `backend/src/main/java/com/careerpath/config/DataSeeder.java` — careers, skills, questions, and optional demo user
- `backend/src/main/java/com/careerpath/service/CareerService.java` — recommendation and skill-gap algorithms
- `backend/src/main/java/com/careerpath/service/RoadmapService.java` — roadmap generation, updates, and progress snapshots
- `backend/src/main/java/com/careerpath/controller/ApiController.java` — REST endpoints
- `frontend/src/pages/Pages.jsx` — product pages and user journeys
- `frontend/src/layouts/AppLayout.jsx` — protected sidebar and top navigation
- `frontend/src/services/api.js` — Axios client and token handling
- `frontend/src/context/AuthContext.jsx` — browser session state

## Screenshots

Add screenshots of the landing page, dashboard, assessment results, skill-gap table, and roadmap here before the college submission.

## Future enhancements

- Admin screens for editing careers and assessment questions
- Email verification and password reset
- Resource links and due dates for roadmap items
- Resume analysis and internship matching
- Production deployment with managed PostgreSQL and HTTPS

## Manual attention before deployment

The included `dev` profile and Docker password are for local demonstration only. Replace the database password and JWT secret with environment variables, set the exact production frontend origin, and disable the demo account before deploying publicly.
